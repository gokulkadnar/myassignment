package com.assignment.AssignmentProject.ExceptionHandler;

public class CustomizeErrorMsg {

    String errorMessage;

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
